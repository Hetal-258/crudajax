jQuery(function($) {
	var val_holder;

	$("form input[name='register']").on('click', function() {

		// form validation
		val_holder 		= 0;
		var fname 		= jQuery.trim($("form input[name='fname']").val()); // first name field
		var email 		= jQuery.trim($("form input[name='email']").val()); // email field
		var email_regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/; // reg ex email check

		if(fname == "") {
			$("span.fname_val").html("This field is empty.");
		val_holder = 1;
		}
		if(email == "") {
			$("span.email_val").html("This field is empty.");
		val_holder = 1;
		}
		if(email != "") {
			if(!email_regex.test(email)){ // if invalid email
				$("span.email_val").html("Your email is invalid.");
				val_holder = 1;
			}
		}
		if(val_holder == 1) {
			return false;
		}
		val_holder = 0;
		// form validation end

		// start
		$("span.loading").html("<img src='images/ajax-loader.gif'>");
		$("span.validation").html("");

		var datastring = 'fname='+ fname +'&email='+ email;
		//var datastring = $('form#mainform').serialize(); // or use serialize

		$.ajax({
					type: "POST", // type
					url: "check_email.php", // request file the 'check_email.php'
					data: datastring, // post the data
					success: function(responseText) { // get the response
						
						if(responseText == 1) { // if the response is 1
							$("span.email_val").html("Email are already exist.");
									} else { // else blank response
						
							if(responseText == "") {
								
								$("span.loading").html(" You are registred. redirecting...");
								$("span.validation").html("");
								$("form input[type='text']").val(''); // optional: empty the field after registration
								
								// your redirect code here
							}
						}
					},
					
		}); // ajax end

	}); // click end
});