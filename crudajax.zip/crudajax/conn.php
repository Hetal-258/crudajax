 <?php
  
    $server_name='localhost'; // host name

    $user_name='root';   // database user name

    $password='M$p@1234';   // database password

    $database_name = "crudajax"; // database name

    $con= mysqli_connect($server_name,$user_name,$password,"$database_name");

      if($con){
        echo"connected";
         
      }
      else{
      	 die('Could not Connect MySql Server:' .mysql_error());
      }
?> 